<?php

$REX['ADDON']['install']['responsiveimg'] = true;

?>