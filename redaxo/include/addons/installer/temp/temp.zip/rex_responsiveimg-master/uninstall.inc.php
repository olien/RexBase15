<?php
$REX['ADDON']['install']['responsiveimg'] = false;
?>