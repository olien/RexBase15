# rex_responsiveimg

Redaxo AddOn für das dynamische Laden verschiedener Image-Manager Bildtypen (je nach Größe des Browserfensters/Bildschirms)

## Installation

* Zip-Archiv herunterladen
* Extrahieren und Ordner in *responsiveimg* umbenennen
* Hochladen und wie gewohnt installieren
* Das jQuery-Plugin im `<head>`-Bereich einbinden.

## Anwendung

Die gewünschten Bildgrößen werden mit dem Image-Manager Addon eingerichtet.

Anschließend können für einen Bildtyp alternative Bildtypen zugewiesen werden, die je nach Seitenauflösung per JS dynamisch ersetzt werden.

-- Weitere Infos folgen... --

